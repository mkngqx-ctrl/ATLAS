# Competing-risks SFSA with three covariates

Open **Glazier_CompetingRisks_3Covariates.ipynb** in Colab. Select a GPU runtime and run the cells in order. The first cell asks for **Glazier_CompetingRisks_3Covariates_Colab.zip** when needed; the next mounts Drive and selects a persistent output location. No previous result archive or Windows path is required.

Start with `MODE='smoke'` to check your Colab session. Change to `MODE='full'` for the benchmark. Its separate output folder prevents smoke checkpoints from being used as full-training checkpoints. Both modes run all ten requested models and all seven samplers for each of Glazier-GRU and Glazier-Transformer. The notebook saves data, checkpoints, individual predictions, exact references, metrics, training logs, plots, source hashes and a combined results ZIP.

| Setting | Smoke | Full |
|---|---:|---:|
| Patients | 1,000 | 50,000 |
| Split | 80/10/10 | 80/10/10 |
| Maximum training epochs | 2 | 200 |
| Early-stopping patience | 2 | 15 |
| Rollouts/live particles M | 64 | 10,000 |
| Sampling seeds | 2 | 5 |
| Starting test patients | 5 | 300 |
| Landmarks | 0, 10, 20 | 0, 10, 20 |

Full DynamicDeepHit also uses five next-state auxiliary burn-in epochs. History models train on all eligible prefixes, so they perform more training work per epoch than the baseline models. Hyperparameters remain explicit, untuned defaults. Full sampling is substantial: there are 249 patient-set prediction files across three landmarks, each containing survival and two CIFs. Actual survivor counts at nonzero landmarks are saved.

## Included methods

CPH; DynamicDeepHIt-Lite; SurvTransformer-Lite; Weibull; DRSA; Glazier-GRU; Glazier-Transformer; DynamicDeepHit; SurvTransformer; SurvTransformer-Discrete. There is also an IID true-generator oracle sampler to show Monte Carlo estimation error.

The seven Glazier methods are IID, stratified uniforms, scrambled Sobol, antithetic uniforms, importance sampling, weighted branching, and conditional Monte Carlo. The first five produce complete observed trajectories. The two particle methods integrate death/censor outcomes and maintain M live histories. Their budgets therefore have different computational meanings. All use cause-aware AJ/product-limit updates: two separate cause-specific KM complements would be incorrect joint CIFs.

## Scenario agreed for this benchmark

- Seven live states: Healthy, Sick_A, Sick_B, Sick_AB, Sicker_A, Sicker_B, Sicker_AB.
- Two absorbing death states: Death_A and Death_B, plus observed dropout Censored.
- Synthetic fixed covariates: calcium in [8,13], age in [30,90], normalized drug level in [0,1], independently uniform by default.
- Disease-specific progression and acquisition of the second condition through AB. Recovery returns from Sicker to Sick.
- Drug increases Sicker_B→Sick_B and Sicker_AB→Sick_AB probabilities by transferring self-transition mass.
- Death_A arises only from Sicker_A/Sicker_AB; Death_B only from Sicker_B/Sicker_AB. From Sicker_AB, Death_A has strictly higher probability for every supported covariate combination.
- No t=20/t=24 clock changes. This new version is a time-homogeneous Markov SFSA with no additional sojourn-duration rule.

**SCENARIO_AND_METHODS.md** provides every transition probability, the censoring convention, reference equations and model adaptations. The response curves are synthetic benchmark choices, not fitted clinical effects or treatment-effect estimates.

## Prediction information and model fidelity

Glazier, DynamicDeepHit and the two new SurvTransformer variants receive all three covariates and the entire observed live-state prefix. Future states are masked/excluded. At baseline, no state is observed; Glazier begins at START and generates each trajectory's own initial state and future history.

CPH, both Lite models, Weibull and DRSA retain their baseline-covariate architecture, generalized to three inputs and two causes. At a later landmark, they condition on survival to that time without re-encoding states. Their landmark comparisons differ in available information from the history models. The generator is Markov, so the current state and covariates are sufficient for its future law; the history models are not explicitly given this simplification.

DynamicDeepHit has two cause-specific PMF heads, one shared tail, latest-conditioned attention, conditional likelihood, cause-specific equal-elapsed-time ranking, and next-state auxiliary prediction. SurvTransformer uses the previously agreed adaptation of SurvTRACE to state/time feature tokens, feature attention, its embedding shortcut, and mortality/duration auxiliary tasks. As selected by the user, the primary multi-cause likelihood sums the released-code PCH losses; no paper-style IPS weighting is added. SurvTransformer-Discrete uses a coherent mutually exclusive discrete-step likelihood. These are documented SFSA adaptations, not exact clinical-study replications.

## Reproducibility and resuming

The notebook mounts Drive before defining output paths. Use the same `RUN_TAG`, settings and code to resume: completed models load from checkpoints and completed prediction files load from disk. An interrupted model restarts its own training. Source/settings/checkpoint checks reject incompatible cached output. Different source or budgets require a new tag. The old hard24 checkpoints have different input and state dimensions and are not reused here.

Overall survival and each cause-specific cumulative incidence are scored separately against exact forward-recursion references. Every prediction must satisfy monotonicity, [0,1] bounds, and S+F_A+F_B=1. MAE averages individual curve errors; mean curves are descriptive. Patient examples are selected by calcium quantiles before looking at errors. Error bars quantify sampling-seed variation, not model-training uncertainty.

The plots folder contains comparison bars for all methods, mean reference/prediction curves, and individual-patient curves for Glazier/Sobol versus the new direct models. The notebook also displays cohort/event summaries and the transition matrix at configurable covariate values.

## Local execution and tests

Open the notebook in your `gpu_env` kernel and run cells in order. It detects the existing workspace support libraries. Tests use `python -m unittest test_competing_risks -v`; no pytest is needed. Dependencies are Python 3.10+, PyTorch with scaled-dot-product attention, NumPy, pandas, SciPy, matplotlib and lifelines. Colab installs the non-PyTorch dependencies and retains its GPU PyTorch installation.

Validation records in `validation/` document numerical checks, a GPU smoke comparison, restart checks, and M=10,000 execution checks. Smoke-trained checkpoints and scores are excluded from the distributable source bundle. Full performance training has not been run as part of notebook construction.
