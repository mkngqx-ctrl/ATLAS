# Scenario and model definitions

## Exact synthetic transition law

Write c=((calcium−8)/5)^2.5, a=max(age−50,0)/40, and d=drug. All three effects lie in [0,1]. Calcium has a bounded Weibull-style power response, age a ReLU threshold response, and drug a linear recovery effect. This does not assert a Weibull distribution for the overall death time. Values are fixed for each patient; time is an abstract unit step.

The table gives every nonzero off-diagonal biological transition. The self-transition probability is one minus the sum of that row's listed entries. All unlisted transitions are zero. Death states are absorbing. The row sums are valid over the complete supported covariate domain.

| From | To | Probability |
|---|---|---:|
| Healthy | Sick_A | .02+.10c+.025a |
| Healthy | Sick_B | .02+.08a+.01c |
| Healthy | Sick_AB | .005+.02ca |
| Sick_A | Healthy | .08/(1+c+.25a) |
| Sick_A | Sicker_A | .04+.20c+.05a |
| Sick_A | Sick_AB | .025+.065a |
| Sick_B | Healthy | .08/(1+a+.25c) |
| Sick_B | Sicker_B | .04+.18a+.04c |
| Sick_B | Sick_AB | .025+.06c |
| Sick_AB | Sick_A | .025 |
| Sick_AB | Sick_B | .025 |
| Sick_AB | Sicker_AB | .05+.15c+.12a |
| Sicker_A | Sick_A | .09 |
| Sicker_A | Sicker_AB | .025+.055a |
| Sicker_A | Death_A | .025+.14c+.08a |
| Sicker_B | Sick_B | .06+.35d |
| Sicker_B | Sicker_AB | .025+.055c |
| Sicker_B | Death_B | .02+.10a+.03c |
| Sicker_AB | Sick_AB | .04+.30d |
| Sicker_AB | Death_B | b=.02+.06a+.025c |
| Sicker_AB | Death_A | 1.8b+.03c+.015 |

The difference between the last two probabilities is .8b+.03c+.015>0. Drug changes only the two specified recovery entries and their self-transition donors. It does not directly change either death entry. This local death preference does not imply Death_A must dominate Death_B in every patient's cumulative incidence, because patients visit different disease states.

The initial s_1 probabilities are: Sick_A .08+.10c; Sick_B .08+.10a; Sick_AB .025+.05ca; Sicker_A .01+.02c; Sicker_B .01+.02a; Sicker_AB .005+.015ca; Healthy gets the remainder. There is no death at step 1 in the true generator. Baseline models receive covariates only; Glazier learns this initial-state distribution through START supervision. No graph restrictions or initial-state distribution are forced on its learned logits.

## Censoring and exact reference

Independent dropout has probability r=.008 per step by default. At each step, draw the biological transition first. A proposed death is observed. If the result is live, an independent dropout draw may replace it with Censored. Equivalently, observed live probabilities are (1−r)Q_sj, death probabilities remain Q_s,Death_k, and the censor probability is r times the total biological live probability. Censored becomes an absorbing observation token. Remaining live paths are administratively censored after step 30.

This convention makes deaths precede censor removal in an integer-time tie. It represents independent censoring of the underlying synthetic biological path: population event-first KM/AJ agrees with biological survival/CIF in this specifically defined generator. This property is verified against the observed-process recursion; it is not inherited as an assumption about earlier hard24 experiments.

At baseline, propagate the covariate-specific distribution of s_1. At a landmark L>0, initialize probability one at the observed live state s_L. If v_t is the live-state mass, the exact updates are v_(t+1)=v_t Q_live and F_k(t+1)=F_k(t)+v_t Q_death_k. Survival is the sum of live-state mass. There is no Monte Carlo noise in these references. The oracle sampler still draws finite observed trajectories and is not an information-theoretic lower bound for all estimators.

For weighted observations with endpoint D_i, cause J_i and weight w_i, define R_t=sum_i w_i 1{D_i>=t} and d_kt=sum_i w_i 1{D_i=t,J_i=k}. Then F_k(t)=F_k(t−1)+S(t−1)d_kt/R_t and S(t)=S(t−1)(1−sum_k d_kt/R_t). Empty risk sets carry the previous values. For unweighted paths w_i=1. This is the AJ competing-risks counterpart of KM, preserving S+F_A+F_B=1.

IID, stratified, scrambled Sobol and antithetic methods change the uniforms passed through each step's categorical inverse CDF. At M=10,000 the strongest power-of-two Sobol balance guarantees do not apply. Importance sampling multiplies both death proposal probabilities by 2 and uses the stopped observed path's exact likelihood ratio. Weighted branching integrates death/censor mass, enumerates seven live successors and resamples M paths. Conditional Monte Carlo integrates death/censor mass, samples a live successor per particle and retains evolving risk-set weights. Particle ESS is recorded before any branching resampling; post-resampling ESS alone would hide weight concentration.

## Model objectives and output conversion

All numerical scaling parameters are fitted on training patients only. Splitting happens before history-prefix expansion. Test patients and exact references do not enter optimization, early stopping or hyperparameter selection. The default training seed is 42 and cohort seed 34001; the saved data include the exact split.

CPH fits a separate three-covariate cause-specific Cox model for each death cause, treating the other death cause as a competing endpoint in that fit. Cause-specific cumulative-hazard increments are combined using the coherent constant-rate interval conversion below. Cox coefficients are not used to claim a causal drug effect.

DynamicDeepHIt-Lite retains its 32-unit baseline-covariate/time GRU and additive attention. SurvTransformer-Lite retains its width-32 baseline-covariate/time Transformer and pooled readout. Their joint softmax has 2×30 cause-time logits plus one shared tail logit. Their objective is joint event/censor likelihood plus the prior cause-specific absolute-time pairwise ranking loss. They use all three covariates but no state-history input.

Weibull retains the two-layer tanh covariate network, now with three inputs and two positive scale/shape pairs. It optimizes the additive cause-specific continuous Weibull likelihood. Prediction uses numerical quadrature of S(t)h_k(t), with strict error and mass checks, and conditions on survival at the landmark. Calling it Weibull does not assert that the SFSA itself has Weibull event times.

DRSA retains the baseline-covariate/time LSTM and three-category interval output (survive, Death_A, Death_B), with its existing alpha=.5 likelihood/event-status objective. Its curves use a shared survival product and cause-specific event accumulation. At nonzero landmarks, all five baseline comparators condition on survival without reading the observed state history.

Glazier-GRU retains its two-layer 32-unit GRU and 8-dimensional state embeddings. Glazier-Transformer retains its two-layer causal width-32, four-head Transformer. Each uses three covariates, ten observed-state output logits, and a distinct START embedding. Teacher forcing includes the first terminal transition and masks subsequent absorbing repetitions. Each sampled continuation conditions on that trajectory's complete prefix. Seven samplers reuse the same fitted checkpoint per architecture.

DynamicDeepHit generalizes the previously implemented history architecture to seven state indicators, three covariates and two causes. It retains the past GRU excluding the latest measurement, attention conditioned on the latest measurement, two cause-specific heads and one jointly normalized tail. Training uses landmark-conditional event/censor likelihood, equal-elapsed-time cause-specific ranking, masked next-state-indicator BCE and L1 regularization. Pairs from the same patient are excluded. Five auxiliary-only burn-in epochs precede full-mode joint training. Validation stopping uses cause-specific elapsed-time concordance over a fixed prefix subset. This is a diagnostic, not an IPCW clinical C-index. [Original Dynamic-DeepHit article](https://doi.org/10.1109/TBME.2019.2909027).

SurvTransformer preserves the agreed SurvTRACE history adaptation: each observed state/time position is a categorical field; the three numeric covariates and landmark are separate tokens. Future fields are masked before attention/readout. Feature attention, the raw-embedding shortcut, SELU alignment, separate cause-hazard heads, and observed mortality/duration auxiliary tasks are retained. Primary training sums the operational cause-specific PCH losses from the released approach; the user selected omission of the article's IPS objective. The task therefore remains an explicitly documented adaptation, not an exact reproduction of either all article components or all public-code architectural choices. [SurvTRACE article](https://arxiv.org/html/2110.00855v2), [released losses](https://github.com/RyanWangZf/SurvTRACE/blob/main/survtrace/losses.py), [released trainer](https://github.com/RyanWangZf/SurvTRACE/blob/main/survtrace/train_utils.py).

Specifically, let a_kj=softplus(z_kj), a_j=sum_k a_kj. The conditional PCH NLL is sum_(j=L+1)^D a_j − 1{J>0}log a_JD. Integer SFSA endpoints occupy the full final interval. Both SurvTransformer variants produce step probabilities p_0j=exp(−a_j), p_kj=(1−exp(−a_j))a_kj/a_j. This ensures mutually exclusive causes and a shared survival probability. CIFs accumulate S_(j−1)p_kj. They are not computed as independent 1−S_k curves.

SurvTransformer-Discrete uses that same architecture and conversion, but its event loss is sum_(j=L+1)^(D−1) a_j − log p_JD. Its censor loss is sum_(j=L+1)^D a_j. This is the exact discrete-step observation likelihood for the stated parameterization. Both variants retain observed-event BCE and observed-duration MSE, each with default weight 1; observed duration is scaled by 30. Censor endpoints remain observed duration targets.

## Interpretation

The default comparison spans 10 learned models, 14 Glazier architecture/sampler combinations, eight direct comparators, and one oracle sampler: 23 method rows per landmark/target. Baseline comparisons share the same three observed covariates, although trajectory-training supervision differs. Landmark comparisons against Lite/CPH/Weibull/DRSA differ in available history and cannot isolate a benefit of sampling alone. The new direct history models address that particular mismatch.

Five sampling seeds measure curve-estimation variability. They do not replace repeated training seeds or validation-based hyperparameter searches. Full benchmark scores must be generated before drawing model-ranking conclusions. Synthetic drug recovery effects and cause preferences are features of this test system, not clinical findings.
